// File: File.hpp
// Author: Garrick Du
// Date: 09/15/2025
// A header file that contains data members and data functions.
#pragma once

#include "FileUtils.hpp"
#include <string>

class File{
private:
    
    std::string filename_; // A string containing the filename of the File object
    bool readable_; // A boolean containing the `read` permission of the File
    bool writable_; // A boolean containing the `write` permission of the File
    timestamp last_modified_timestamp_;

    // Helper to update timestamp
    void updateTimestamp();

public:
    //Default Constructor
    File();
    //Parameterized Constructor, where the default value of the boolean parameters is true.
    File(const std::string& filename, bool isReadable = true, bool isWritable = true);

    //Getters
    std::string getFilename() const;
    bool isReadable() const;
    bool isWritable() const;
    timestamp getLastModified() const;

    //Setters
    bool setFilename(const std::string &filename);
    void setReadable(const bool &new_permission);
    void setWritable(const bool &new_permission);
};
