#include <iostream>
#include "File.hpp"

int main() {
    // Test 1: Default constructor
    File f1;
    std::cout << "Default constructor test:" << std::endl;
    std::cout << "Filename: " << f1.getFilename() << std::endl;
    std::cout << "Readable: " << (f1.isReadable() ? "true" : "false") << std::endl;
    std::cout << "Writable: " << (f1.isWritable() ? "true" : "false") << std::endl;
    std::cout << std::endl;

    // Test 2: Parameterized constructor
    File f2("example", true, false);
    std::cout << "Parameterized constructor test:" << std::endl;
    std::cout << "Filename: " << f2.getFilename() << std::endl;
    std::cout << "Readable: " << (f2.isReadable() ? "true" : "false") << std::endl;
    std::cout << "Writable: " << (f2.isWritable() ? "true" : "false") << std::endl;
    std::cout << std::endl;

    // Test 3: Modifying properties
    std::cout << "After modifying permissions and filename:" << std::endl;
    f2.setReadable(false);
    f2.setWritable(true);
    if (f2.setFilename("example.txt")) {
        std::cout << "Filename successfully changed!" << std::endl;
    } else {
        std::cout << "Filename change failed!" << std::endl;
    }

    std::cout << "Filename: " << f2.getFilename() << std::endl;
    std::cout << "Readable: " << (f2.isReadable() ? "true" : "false") << std::endl;
    std::cout << "Writable: " << (f2.isWritable() ? "true" : "false") << std::endl;
    std::cout << std::endl;

    return 0;
}