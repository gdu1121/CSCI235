// File: FileUtils.cpp
// Author: Garrick Du
// Date: 09/15/2025
// A file with carious utilites.
#include "FileUtils.hpp"

std::string timestampToString(timestamp time_point)
{
    std::time_t tt = cr::system_clock::to_time_t(time_point);
    std::tm streamable_time = *std::localtime(&tt);

    std::stringstream ss;
    ss << std::put_time(&streamable_time, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

// YOUR CODE BELOW HERE --------
/*
Task 1 Part A:
Implementing findFileExtension:
 * Extracts the file extension from a given filename.
 *
 * We define the file extension as the string containing:
 * 1. The last period within the filename
 * 2. All characters after that period
 *
 * @pre Assume the given filename has no spaces
 * @param filename A const reference to a string representing the filename from which to find the extension.
 * @return A string containing the extracted file extension or an empty string if:
 *  1. No extension is found
 *  2. The filename is empty.
*/
std::string FileUtils::findFileExtension(const std::string &filename){
    // If filename is empty, return ""
    if (filename.empty()) {
            return "";
    }

    // Find the last occurrence of '.'
    size_t lastDotPos = filename.find_last_of('.');

    // If no '.' found, then we do not have an extension
    if (lastDotPos == std::string::npos) {
        return "";
    }

    // Extract from '.' to the end
    return filename.substr(lastDotPos);
}


/*
Task 1 Part B:
Create the function hasWhitespaces:
 * Checks if a given filename contains any whitespace characters.
 *
 * A whitespace character is any character matching the STL documentation in the link below.
 *
 * @param filename A const reference to a string representing the filename to check for spaces.
 * @return true if the filename contains one or more whitespace characters, false otherwise.
 * @see https://en.cppreference.com/w/cpp/string/byte/isspace.html
 */
bool FileUtils::hasWhitespaces(const std::string &filename) {
    for (char c : filename) {
        if (std::isspace(static_cast<unsigned char>(c))) {
            return true;
        }
    }
    return false;
}
